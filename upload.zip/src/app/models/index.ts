





export let periodUnits = [
    { label: 'دقیقه', value: 'minute' },
    { label: 'ساعت', value: 'hour' },
    { label: 'روز', value: 'day' },
    { label: 'ماه', value: 'month' },
    { label: 'سال', value: 'year' }
]

export let currencies = ['ریال', 'تومان', 'دلار', 'یورو', 'یوآن'];


// gridLayout: { containers: { tabs: { active: boolean, widgets: { id: string } [] } [] } [] } = {
//     containers: []
// };
