import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sms-service',
  templateUrl: './sms-service.component.html',
  styleUrls: ['./sms-service.component.css']
})
export class SmsServiceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
