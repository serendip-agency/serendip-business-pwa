import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fax-service',
  templateUrl: './fax-service.component.html',
  styleUrls: ['./fax-service.component.css']
})
export class FaxServiceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
