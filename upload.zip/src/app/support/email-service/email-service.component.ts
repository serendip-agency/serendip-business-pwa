import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-email-service',
  templateUrl: './email-service.component.html',
  styleUrls: ['./email-service.component.css']
})
export class EmailServiceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
