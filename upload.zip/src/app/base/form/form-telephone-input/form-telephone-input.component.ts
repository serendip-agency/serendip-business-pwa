import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form-telephone-input',
  templateUrl: './form-telephone-input.component.html',
  styleUrls: ['./form-telephone-input.component.css']
})
export class FormTelephoneInputComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
