import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form-relative-date-input',
  templateUrl: './form-relative-date-input.component.html',
  styleUrls: ['./form-relative-date-input.component.css']
})
export class FormRelativeDateInputComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
