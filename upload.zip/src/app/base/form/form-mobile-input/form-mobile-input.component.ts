import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form-mobile-input',
  templateUrl: './form-mobile-input.component.html',
  styleUrls: ['./form-mobile-input.component.css']
})
export class FormMobileInputComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
