import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form-country-input',
  templateUrl: './form-country-input.component.html',
  styleUrls: ['./form-country-input.component.css']
})
export class FormCountryInputComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
