import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-account-sessions',
  templateUrl: './account-sessions.component.html',
  styleUrls: ['./account-sessions.component.css']
})
export class AccountSessionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
