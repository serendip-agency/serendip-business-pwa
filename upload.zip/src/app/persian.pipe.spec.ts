import { PersianPipe } from './persian.pipe';
describe('PersianPipe', () => {
  it('create an instance', () => {
    const pipe = new PersianPipe();

    expect(pipe).toBeTruthy();

  }
);

}
);

