import { Split3Pipe } from './split3.pipe';

describe('Split3Pipe', () => {
  it('create an instance', () => {
    const pipe = new Split3Pipe();
    expect(pipe).toBeTruthy();
  });
});
