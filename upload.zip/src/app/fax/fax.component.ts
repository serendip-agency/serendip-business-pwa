import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fax',
  templateUrl: './fax.component.html',
  styleUrls: ['./fax.component.css']
})
export class FaxComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
