export class InsertMessage {

    constructor(public item,public date?,public user?){

    }

}