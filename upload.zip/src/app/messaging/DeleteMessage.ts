export class DeleteMessage {

    constructor(public item,public date?,public user?){

    }

}