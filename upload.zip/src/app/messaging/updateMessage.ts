export class UpdateMessage {

    constructor(public item,public date?,public user?){

    }

}