import { RpdPipe } from './rpd.pipe';

describe('RpdPipe', () => {
  it('create an instance', () => {
    const pipe = new RpdPipe();
    expect(pipe).toBeTruthy();
  });
});
