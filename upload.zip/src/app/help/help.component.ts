import { Component, OnInit, Input } from "@angular/core";

@Component({
  selector: "app-help",
  templateUrl: "./help.component.html",
  styleUrls: ["./help.component.less"]
})
export class HelpComponent implements OnInit {
  constructor() {}

  @Input() id;

  ngOnInit() {}
}
