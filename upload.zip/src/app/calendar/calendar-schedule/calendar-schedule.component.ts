import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-calendar-schedule',
  templateUrl: './calendar-schedule.component.html',
  styleUrls: ['./calendar-schedule.component.css']
})
export class CalendarScheduleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
