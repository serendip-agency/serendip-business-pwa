import { TPipe } from './t.pipe';

describe('TPipe', () => {
  it('create an instance', () => {
    const pipe = new TPipe();
    expect(pipe).toBeTruthy();
  });
});
