import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-connect-database',
  templateUrl: './connect-database.component.html',
  styleUrls: ['./connect-database.component.less']
})
export class ConnectDatabaseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
