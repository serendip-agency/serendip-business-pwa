import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-storage-files',
  templateUrl: './storage-files.component.html',
  styleUrls: ['./storage-files.component.css']
})
export class StorageFilesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
