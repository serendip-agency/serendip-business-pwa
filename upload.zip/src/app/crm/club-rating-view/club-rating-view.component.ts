import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-club-rating-view',
  templateUrl: './club-rating-view.component.html',
  styleUrls: ['./club-rating-view.component.css']
})
export class ClubRatingViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
